package lab02;

public class TimingExperiment02 {

    public static void main(String[] args) {
        long secondsToRun = 1;
        long startTime = System.currentTimeMillis();
        long lastTime = startTime;
        int advanceCount = 0;
        int loopCount = 0;
        while (lastTime - startTime < 1000 * secondsToRun) {
            loopCount++;
            long currentTime = System.currentTimeMillis();
            if (currentTime == lastTime)
                continue;
            lastTime = currentTime;
            advanceCount++;
        }
        double advancesPerSecond = advanceCount / (double) secondsToRun;
        System.out.println("Time advanced " + advancesPerSecond + " times per second.");
        System.out.println("The loop tested the time " + loopCount + " times.");
    }
} // One iteration of the loop is less than one millisecond. One second isn't long enough to get an answer as the stated number
// of loops changes as we perform the test more times. There is still variation at 10 seconds but it seems more consistent.